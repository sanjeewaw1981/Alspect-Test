import React, { useState, useEffect } from 'react';
import './JobList.css';

const JobList = () => {
    const [jobs, setJobs] = useState([]);
    const [newJob, setNewJob] = useState({ title: '', description: '' });

    useEffect(() => {
        fetchJobs();
    }, []);

    const fetchJobs = async () => {
        try {
            const response = await fetch("http://localhost:5000/api/jobs");
            if (!response.ok) {
                throw new Error("Network response was not ok");
            }
            const data = await response.json();
            setJobs(data);
        } catch (error) {
            console.error("Error fetching jobs", error);
        }
    };
    
    const addJob = async () => {
        const job = { title: newJob.title, description: newJob.description, subItems: [] };
        try {
            const response = await fetch("http://localhost:5000/api/jobs", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(job)
            });
            if (!response.ok) {
                throw new Error("Error adding job");
            }
            fetchJobs();
            setNewJob({ title: '', description: '' });
        } catch (error) {
            console.error("Error adding job", error);
        }
    };

    const getTextColor = (status) => {
        switch (status) {
            case 'Pending':
                return 'red';
            case 'In Progress':
                return 'orange';
            case 'Completed':
                return 'green';
            default:
                return 'black';
        }
    };

    return (
        <div>
            <div class="title">
                <span class="highlight">Al</span>spec <span class="highlight">Pr</span>oducts
            </div>
            <br></br><br></br>
            <div>
                <button class="button" onClick={addJob}>Add Job</button>
            </div>
            {Array.isArray(jobs) ? jobs.map((job) => (
                <table>
                    <tr>
                        <td><strong>JobId</strong></td>
                        <td><strong>Title</strong></td>
                        <td><strong>Description</strong></td>
                    </tr>
                    <tr>
                        <td>{job.id}</td>
                        <td>{job.title}</td>
                        <td>{job.description}</td>    
                    </tr>
                    <tr>
                        <td></td>
                        <td colSpan={2} className='items'>
                        {job.subItems.map((subItem) => (
                            <table className='border'>
                                <tr>
                                    <td>
                                        <div style={{ color: getTextColor(subItem.status) }} key={subItem.itemId}>
                                            <strong>ItmeId:</strong> {subItem.itemId} <br/>
                                            <strong>Title:</strong> {subItem.title} <br/>
                                            <strong>Description:</strong> {subItem.description} <br/>
                                        </div>
                                    </td>
                                </tr>
                            </table>
                            ))}
                        </td>
                    </tr>
                </table>
                    
                )): <p>No jobs available.</p>}
        </div>
    );
};

export default JobList;