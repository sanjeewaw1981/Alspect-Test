import logo from './logo.svg';
import './App.css';
import JobList from './JobList';

function App() {
  return (
    <div className="App">
      <JobList />
    </div>
  );
}

export default App;
